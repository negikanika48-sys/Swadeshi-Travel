"use client"

import { useState, useMemo } from "react"
import { HeroSection } from "@/components/hero-section"
import { StateCard } from "@/components/state-card"
import { states } from "@/lib/states-data"
import { Button } from "@/components/ui/button"

const regions = [
  { id: "all", label: "All States" },
  { id: "north", label: "North India" },
  { id: "south", label: "South India" },
  { id: "east", label: "East India" },
  { id: "west", label: "West India" },
  { id: "central", label: "Central India" },
  { id: "northeast", label: "Northeast India" },
]

export default function SwadeshiTravel() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRegion, setSelectedRegion] = useState("all")

  const filteredStates = useMemo(() => {
    return states.filter((state) => {
      const matchesSearch =
        state.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        state.highlight.toLowerCase().includes(searchQuery.toLowerCase()) ||
        state.tagline.toLowerCase().includes(searchQuery.toLowerCase())
      
      const matchesRegion = selectedRegion === "all" || state.region === selectedRegion
      
      return matchesSearch && matchesRegion
    })
  }, [searchQuery, selectedRegion])

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <HeroSection searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      {/* States Section */}
      <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Explore Indian States
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Each state has its own unique culture, traditions, and breathtaking destinations. 
            Start your journey through incredible India.
          </p>
        </div>

        {/* Region Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {regions.map((region) => (
            <Button
              key={region.id}
              variant={selectedRegion === region.id ? "default" : "outline"}
              onClick={() => setSelectedRegion(region.id)}
              className={`rounded-full transition-all ${
                selectedRegion === region.id
                  ? "bg-amber-600 hover:bg-amber-700 text-white"
                  : "border-amber-200 text-amber-700 hover:bg-amber-50 hover:border-amber-300"
              }`}
            >
              {region.label}
            </Button>
          ))}
        </div>

        {/* States Grid */}
        {filteredStates.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStates.map((state) => (
              <StateCard
                key={state.id}
                id={state.id}
                name={state.name}
                image={state.image}
                tagline={state.tagline}
                highlight={state.highlight}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-lg text-muted-foreground">
              No states found matching your search. Try a different keyword.
            </p>
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="bg-amber-50 py-12 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h3 className="text-2xl font-bold text-amber-800 mb-2">Swadeshi Travel</h3>
          <p className="text-amber-700 mb-6">Discover the beauty of India, one state at a time.</p>
          <div className="flex justify-center gap-6 text-sm text-amber-600">
            <span>28 States</span>
            <span>|</span>
            <span>100+ Destinations</span>
            <span>|</span>
            <span>Authentic Experiences</span>
          </div>
          <p className="text-amber-600/70 mt-8 text-sm">
            Made with love for India
          </p>
        </div>
      </footer>
    </main>
  )
}
