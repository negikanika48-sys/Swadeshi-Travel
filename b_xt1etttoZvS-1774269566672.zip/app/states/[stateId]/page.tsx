import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowLeft, MapPin, Utensils, Palette } from "lucide-react"
import { states } from "@/lib/states-data"
import { stateDetails } from "@/lib/state-details"
import { FoodCard } from "@/components/food-card"
import { CultureCard } from "@/components/culture-card"
import { Button } from "@/components/ui/button"

interface StatePageProps {
  params: Promise<{ stateId: string }>
}

export async function generateStaticParams() {
  return states.map((state) => ({
    stateId: state.id,
  }))
}

export async function generateMetadata({ params }: StatePageProps) {
  const { stateId } = await params
  const state = states.find((s) => s.id === stateId)
  
  if (!state) {
    return {
      title: "State Not Found",
    }
  }

  return {
    title: `${state.name} - Swadeshi Travel`,
    description: `Explore the culture, cuisine, and heritage of ${state.name}. ${state.tagline}`,
  }
}

export default async function StatePage({ params }: StatePageProps) {
  const { stateId } = await params
  const state = states.find((s) => s.id === stateId)
  const details = stateDetails[stateId]

  if (!state || !details) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative h-[60vh] min-h-[400px] overflow-hidden">
        <Image
          src={state.image}
          alt={state.name}
          fill
          className="object-cover"
          priority
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/20" />
        
        {/* Back Button */}
        <div className="absolute top-6 left-6 z-10">
          <Link href="/">
            <Button variant="secondary" size="sm" className="gap-2 bg-white/90 hover:bg-white text-foreground">
              <ArrowLeft className="h-4 w-4" />
              Back to States
            </Button>
          </Link>
        </div>

        {/* Hero Content */}
        <div className="absolute bottom-0 left-0 right-0 p-8 md:p-12">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-2 text-amber-400 mb-3">
              <MapPin className="h-5 w-5" />
              <span className="text-sm font-medium uppercase tracking-wider">{state.highlight}</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-3">{state.name}</h1>
            <p className="text-xl md:text-2xl text-white/90 font-light">{state.tagline}</p>
          </div>
        </div>
      </section>

      {/* Description Section */}
      <section className="py-12 px-6 md:px-12 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <p className="text-lg text-muted-foreground leading-relaxed text-center">
            {details.description}
          </p>
        </div>
      </section>

      {/* Food Section */}
      <section className="py-16 px-6 md:px-12">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 bg-amber-100 rounded-full">
              <Utensils className="h-6 w-6 text-amber-600" />
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground">Culinary Delights</h2>
              <p className="text-muted-foreground">Taste the authentic flavors of {state.name}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {details.foods.map((food, index) => (
              <FoodCard key={index} {...food} />
            ))}
          </div>
        </div>
      </section>

      {/* Culture Section */}
      <section className="py-16 px-6 md:px-12 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 bg-rose-100 rounded-full">
              <Palette className="h-6 w-6 text-rose-600" />
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground">Culture & Traditions</h2>
              <p className="text-muted-foreground">Discover the rich heritage and craftsmanship</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {details.culture.map((item, index) => (
              <CultureCard key={index} {...item} />
            ))}
          </div>
        </div>
      </section>

      {/* Back to Home */}
      <section className="py-12 px-6 md:px-12">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-muted-foreground mb-4">Explore more destinations across India</p>
          <Link href="/">
            <Button className="gap-2 bg-amber-600 hover:bg-amber-700 text-white">
              <ArrowLeft className="h-4 w-4" />
              Explore All States
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
