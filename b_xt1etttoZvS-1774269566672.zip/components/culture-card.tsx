"use client"

import Image from "next/image"

interface CultureCardProps {
  name: string
  image: string
  description: string
}

export function CultureCard({ name, image, description }: CultureCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-xl bg-card border border-border shadow-sm transition-all duration-300 hover:shadow-lg hover:border-primary/20">
      <div className="flex flex-col md:flex-row">
        <div className="relative h-48 md:h-auto md:w-40 flex-shrink-0 overflow-hidden">
          <Image
            src={image}
            alt={name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
            sizes="(max-width: 768px) 100vw, 160px"
          />
        </div>
        <div className="p-4 flex flex-col justify-center">
          <h3 className="text-lg font-semibold text-foreground mb-2">{name}</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
        </div>
      </div>
    </div>
  )
}
