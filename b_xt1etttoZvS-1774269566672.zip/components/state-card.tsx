"use client"

import Image from "next/image"
import Link from "next/link"
import { MapPin } from "lucide-react"

interface StateCardProps {
  id: string
  name: string
  image: string
  tagline: string
  highlight: string
}

export function StateCard({ id, name, image, tagline, highlight }: StateCardProps) {
  return (
    <Link href={`/states/${id}`} className="block">
      <div className="group relative overflow-hidden rounded-2xl bg-card shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer">
        <div className="relative h-72 overflow-hidden">
          <Image
            src={image}
            alt={`${name} - ${highlight}`}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-5">
            <div className="flex items-center gap-2 text-amber-400 mb-2">
              <MapPin className="h-4 w-4" />
              <span className="text-sm font-medium">{highlight}</span>
            </div>
            <h3 className="text-2xl font-bold text-white mb-1">{name}</h3>
            <p className="text-sm text-white/80">{tagline}</p>
          </div>
        </div>
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 text-xs font-semibold text-amber-700 group-hover:bg-amber-500 group-hover:text-white transition-colors duration-300">
          Explore
        </div>
      </div>
    </Link>
  )
}
