export interface Food {
  name: string
  image: string
  description: string
}

export interface Culture {
  name: string
  image: string
  description: string
}

export interface StateDetail {
  id: string
  description: string
  foods: Food[]
  culture: Culture[]
}

export const stateDetails: Record<string, StateDetail> = {
  "punjab": {
    id: "punjab",
    description: "Punjab, the land of five rivers, is known for its vibrant culture, rich history, and warm hospitality. From the spiritual Golden Temple to the energetic Bhangra dance, Punjab offers an unforgettable experience of Indian traditions.",
    foods: [
      {
        name: "Sarson da Saag & Makki di Roti",
        image: "https://images.unsplash.com/photo-1645177628172-a94c1f96e6db?w=800&q=80",
        description: "Traditional winter delicacy of mustard greens served with cornmeal flatbread and white butter."
      },
      {
        name: "Butter Chicken",
        image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=800&q=80",
        description: "Creamy tomato-based curry with tender chicken pieces, a Punjabi classic loved worldwide."
      },
      {
        name: "Lassi",
        image: "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&q=80",
        description: "Refreshing yogurt-based drink, either sweet or salted, perfect for Punjab's warm climate."
      }
    ],
    culture: [
      {
        name: "Phulkari Embroidery",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Traditional floral embroidery work done on shawls and dupattas using colorful silk threads."
      },
      {
        name: "Bhangra Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Energetic folk dance performed during harvest festivals, accompanied by dhol drums."
      },
      {
        name: "Punjabi Jutti",
        image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&q=80",
        description: "Handcrafted leather footwear with intricate embroidery, a symbol of Punjabi craftsmanship."
      }
    ]
  },
  "uttar-pradesh": {
    id: "uttar-pradesh",
    description: "Uttar Pradesh, home to the iconic Taj Mahal and sacred city of Varanasi, is the spiritual heartland of India. It showcases centuries of Mughal heritage, Hindu pilgrimage sites, and a rich culinary tradition.",
    foods: [
      {
        name: "Tunday Kebab",
        image: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=800&q=80",
        description: "Legendary Lucknowi kebabs made with minced meat and 160 spices, melt-in-mouth delicacy."
      },
      {
        name: "Petha",
        image: "https://images.unsplash.com/photo-1605196560547-b79f21c00b78?w=800&q=80",
        description: "Agra's famous sweet made from ash gourd, translucent and available in various flavors."
      },
      {
        name: "Bedai & Kachori",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
        description: "Deep-fried puffed bread stuffed with spiced lentils, served with tangy potato curry."
      }
    ],
    culture: [
      {
        name: "Chikankari Embroidery",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Delicate hand embroidery from Lucknow, featuring intricate white threadwork on fabric."
      },
      {
        name: "Banarasi Silk Weaving",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "World-famous silk sarees woven with gold and silver threads in Varanasi."
      },
      {
        name: "Kathak Dance",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Classical dance form originating from UP, known for rhythmic footwork and expressions."
      }
    ]
  },
  "uttarakhand": {
    id: "uttarakhand",
    description: "Uttarakhand, known as Dev Bhoomi (Land of Gods), is nestled in the Himalayas. Home to sacred pilgrimage sites, pristine rivers, and stunning mountain vistas, it offers spiritual solace and adventure alike.",
    foods: [
      {
        name: "Kafuli",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Nutritious spinach and fenugreek curry cooked in iron kadhai, a Garhwali specialty."
      },
      {
        name: "Aloo Ke Gutke",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Spiced potato dish with local herbs, a staple comfort food of the hills."
      },
      {
        name: "Bal Mithai",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Chocolate-like fudge coated with white sugar balls, Almora's signature sweet."
      }
    ],
    culture: [
      {
        name: "Aipan Art",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Traditional floor and wall art using rice paste, depicting geometric and ritualistic patterns."
      },
      {
        name: "Wool Weaving",
        image: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800&q=80",
        description: "Handwoven woolen shawls and blankets from the mountain regions, warm and durable."
      },
      {
        name: "Ringaal Craft",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Bamboo basketry and household items crafted by skilled artisans of the region."
      }
    ]
  },
  "himachal-pradesh": {
    id: "himachal-pradesh",
    description: "Himachal Pradesh, the abode of snow, enchants visitors with its snow-capped peaks, apple orchards, and ancient temples. From Shimla's colonial charm to Spiti's rugged beauty, it's a paradise for nature lovers.",
    foods: [
      {
        name: "Siddu",
        image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&q=80",
        description: "Steamed wheat bread stuffed with poppy seeds or walnuts, served with ghee."
      },
      {
        name: "Madra",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Creamy chickpea curry cooked in yogurt gravy, a Himachali festive essential."
      },
      {
        name: "Babru",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
        description: "Deep-fried black gram stuffed bread, crispy outside and flavorful inside."
      }
    ],
    culture: [
      {
        name: "Kullu Shawls",
        image: "https://images.unsplash.com/photo-1601244005535-a48d21d951ac?w=800&q=80",
        description: "Handwoven woolen shawls with vibrant geometric patterns, a GI-tagged heritage."
      },
      {
        name: "Chamba Rumal",
        image: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800&q=80",
        description: "Embroidered handkerchiefs depicting mythological scenes, a 300-year-old tradition."
      },
      {
        name: "Wood Carving",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Intricate woodwork seen in temples and traditional homes across the state."
      }
    ]
  },
  "haryana": {
    id: "haryana",
    description: "Haryana, the land of Mahabharata, bridges ancient history with modern progress. Known for its agricultural prosperity, folk traditions, and the sacred Kurukshetra, it showcases India's rural heartland.",
    foods: [
      {
        name: "Bajra Khichdi",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Wholesome millet and lentil porridge, served with ghee and buttermilk."
      },
      {
        name: "Kadhi Pakora",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Yogurt-based curry with crispy gram flour fritters, a Haryanvi comfort food."
      },
      {
        name: "Churma",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Sweet crumbled wheat dish mixed with ghee and jaggery, traditionally prepared for festivals."
      }
    ],
    culture: [
      {
        name: "Phulkari Work",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Floral embroidery on cloth using colorful threads, worn during celebrations."
      },
      {
        name: "Pottery & Terracotta",
        image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800&q=80",
        description: "Traditional clay crafts including decorative items and functional pottery."
      },
      {
        name: "Saang Folk Theatre",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Traditional musical drama depicting mythological and social themes."
      }
    ]
  },
  "rajasthan": {
    id: "rajasthan",
    description: "Rajasthan, the land of kings, mesmerizes with its majestic forts, vibrant deserts, and royal heritage. From the pink city of Jaipur to the golden sands of Jaisalmer, it's a living testament to India's regal past.",
    foods: [
      {
        name: "Dal Baati Churma",
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=800&q=80",
        description: "Iconic Rajasthani meal of baked wheat balls with lentils and sweet churma."
      },
      {
        name: "Gatte ki Sabzi",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Spiced gram flour dumplings in tangy yogurt gravy, a desert delicacy."
      },
      {
        name: "Ker Sangri",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Wild beans and berries cooked with spices, unique to the Thar desert region."
      }
    ],
    culture: [
      {
        name: "Bandhani Tie-Dye",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Traditional tie-dye technique creating intricate patterns on fabric."
      },
      {
        name: "Blue Pottery",
        image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800&q=80",
        description: "Persian-influenced ceramic art using blue dye, unique to Jaipur."
      },
      {
        name: "Ghoomar Dance",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Graceful folk dance performed by women in swirling ghagras."
      }
    ]
  },
  "gujarat": {
    id: "gujarat",
    description: "Gujarat, the land of legends, gave India its Father of the Nation. From the white desert of Kutch to the lions of Gir, it blends wildlife, heritage, and an entrepreneurial spirit unique to the region.",
    foods: [
      {
        name: "Dhokla",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
        description: "Steamed fermented gram flour snack, light, tangy, and healthy."
      },
      {
        name: "Undhiyu",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Mixed vegetable casserole with fenugreek dumplings, a winter specialty."
      },
      {
        name: "Thepla",
        image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&q=80",
        description: "Spiced fenugreek flatbread, perfect travel food loved by Gujaratis worldwide."
      }
    ],
    culture: [
      {
        name: "Patola Weaving",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Double ikat silk sarees from Patan, among the world's finest textiles."
      },
      {
        name: "Kutchi Embroidery",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Mirror work embroidery by tribal communities of Kutch."
      },
      {
        name: "Garba Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Circular folk dance performed during Navratri with colorful sticks."
      }
    ]
  },
  "maharashtra": {
    id: "maharashtra",
    description: "Maharashtra, the land of Maratha warriors, combines modern Mumbai's energy with ancient Ajanta's art. From hill stations to coastal beaches, it offers diverse experiences rooted in rich cultural heritage.",
    foods: [
      {
        name: "Vada Pav",
        image: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=800&q=80",
        description: "Mumbai's iconic street food - spiced potato fritter in bread with chutneys."
      },
      {
        name: "Puran Poli",
        image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&q=80",
        description: "Sweet flatbread stuffed with jaggery-lentil filling, festive favorite."
      },
      {
        name: "Misal Pav",
        image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800&q=80",
        description: "Spicy sprouted bean curry topped with farsan, served with bread."
      }
    ],
    culture: [
      {
        name: "Paithani Sarees",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Handwoven silk sarees with peacock motifs, Maharashtra's pride."
      },
      {
        name: "Warli Painting",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Tribal art using geometric shapes to depict daily life and nature."
      },
      {
        name: "Lavani Dance",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Powerful folk dance combining traditional music with strong rhythms."
      }
    ]
  },
  "goa": {
    id: "goa",
    description: "Goa, India's smallest state, is a tropical paradise blending Portuguese heritage with Indian charm. Famous for beaches, churches, and vibrant nightlife, it offers a unique coastal culture unlike anywhere else in India.",
    foods: [
      {
        name: "Fish Curry Rice",
        image: "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&q=80",
        description: "Tangy coconut-based fish curry with steamed rice, the Goan staple."
      },
      {
        name: "Bebinca",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Seven-layered coconut milk pudding, a traditional Goan Christmas dessert."
      },
      {
        name: "Prawn Balchão",
        image: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=800&q=80",
        description: "Fiery prawn pickle curry with Portuguese influences, tangy and spicy."
      }
    ],
    culture: [
      {
        name: "Azulejos Tiles",
        image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800&q=80",
        description: "Portuguese ceramic tilework adorning churches and heritage homes."
      },
      {
        name: "Feni Craft",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Traditional cashew or coconut spirit, GI-tagged Goan heritage drink."
      },
      {
        name: "Fugdi Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Circle dance performed by women during religious festivals."
      }
    ]
  },
  "kerala": {
    id: "kerala",
    description: "Kerala, God's Own Country, enchants with backwaters, spice gardens, and Ayurvedic traditions. From houseboat cruises to Kathakali performances, it offers a serene escape into nature and culture.",
    foods: [
      {
        name: "Appam with Stew",
        image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=800&q=80",
        description: "Lacy rice pancakes served with creamy coconut vegetable stew."
      },
      {
        name: "Puttu & Kadala",
        image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&q=80",
        description: "Steamed rice cylinders with coconut, served with chickpea curry."
      },
      {
        name: "Kerala Sadya",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Grand vegetarian feast served on banana leaf during Onam festival."
      }
    ],
    culture: [
      {
        name: "Kathakali",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Classical dance-drama with elaborate costumes and expressive makeup."
      },
      {
        name: "Coir Weaving",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Coconut fiber crafts including mats, ropes, and decorative items."
      },
      {
        name: "Aranmula Kannadi",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Unique metal mirrors made using secret alloy, a centuries-old craft."
      }
    ]
  },
  "tamil-nadu": {
    id: "tamil-nadu",
    description: "Tamil Nadu, cradle of Dravidian culture, boasts magnificent temples, classical arts, and ancient traditions. From Madurai's Meenakshi Temple to Chennai's beaches, it preserves India's oldest living heritage.",
    foods: [
      {
        name: "Idli Sambar",
        image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=800&q=80",
        description: "Steamed rice cakes with lentil soup, the quintessential South Indian breakfast."
      },
      {
        name: "Dosa",
        image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=800&q=80",
        description: "Crispy fermented crepe, versatile and loved across India and beyond."
      },
      {
        name: "Pongal",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Rice and lentil dish, both sweet and savory versions for harvest festival."
      }
    ],
    culture: [
      {
        name: "Bharatanatyam",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Ancient classical dance form originating from temple traditions."
      },
      {
        name: "Kanchipuram Silk",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Lustrous silk sarees with temple borders, bridal favorites."
      },
      {
        name: "Tanjore Painting",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Gold foil embellished paintings depicting Hindu deities."
      }
    ]
  },
  "karnataka": {
    id: "karnataka",
    description: "Karnataka, one state with many worlds, ranges from tech hub Bengaluru to ancient Hampi's ruins. It celebrates diverse landscapes, from Western Ghats to coastal beaches, with rich royal heritage.",
    foods: [
      {
        name: "Bisi Bele Bath",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Spiced rice with lentils and vegetables, a Karnataka comfort classic."
      },
      {
        name: "Mysore Pak",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Melt-in-mouth gram flour fudge from the Mysore palace kitchens."
      },
      {
        name: "Ragi Mudde",
        image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&q=80",
        description: "Nutritious finger millet balls served with spicy curry, rural staple."
      }
    ],
    culture: [
      {
        name: "Mysore Silk",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Pure silk sarees with zari work, a GI-tagged Karnataka heritage."
      },
      {
        name: "Yakshagana",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Traditional theatre combining dance, music, and elaborate costumes."
      },
      {
        name: "Bidriware",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Silver inlay work on blackened alloy, unique to Bidar region."
      }
    ]
  },
  "andhra-pradesh": {
    id: "andhra-pradesh",
    description: "Andhra Pradesh, essence of South India, features the sacred Tirumala temple and historic Amaravati. Known for spicy cuisine and Kuchipudi dance, it blends devotion with vibrant cultural expressions.",
    foods: [
      {
        name: "Pulihora",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Tangy tamarind rice, a temple prasad and everyday favorite."
      },
      {
        name: "Gongura Pachadi",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Sorrel leaves chutney, distinctively sour and spicy Andhra specialty."
      },
      {
        name: "Pesarattu",
        image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=800&q=80",
        description: "Green gram dosa, protein-rich breakfast unique to Andhra region."
      }
    ],
    culture: [
      {
        name: "Kuchipudi Dance",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Classical dance-drama originating from Krishna district villages."
      },
      {
        name: "Kalamkari",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Hand-painted cotton textiles using natural dyes and pen work."
      },
      {
        name: "Kondapalli Toys",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Colorful wooden toys depicting rural life and mythology."
      }
    ]
  },
  "telangana": {
    id: "telangana",
    description: "Telangana, India's youngest state, centers around historic Hyderabad with its iconic Charminar. It blends Nizami elegance with Telugu traditions, offering royal cuisine and Deccan heritage.",
    foods: [
      {
        name: "Hyderabadi Biryani",
        image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&q=80",
        description: "Aromatic rice layered with spiced meat, the crown jewel of Hyderabadi cuisine."
      },
      {
        name: "Haleem",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Slow-cooked meat and wheat porridge, especially popular during Ramadan."
      },
      {
        name: "Double ka Meetha",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Bread pudding soaked in saffron milk, a Nizami dessert tradition."
      }
    ],
    culture: [
      {
        name: "Bidri Craft",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Metal handicraft with silver inlay on zinc-copper alloy."
      },
      {
        name: "Pochampally Ikat",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Geometric patterned textiles using resist dyeing technique."
      },
      {
        name: "Perini Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Ancient warrior dance revived from Kakatiya dynasty temples."
      }
    ]
  },
  "odisha": {
    id: "odisha",
    description: "Odisha, soul of India, treasures ancient temples and tribal heritage. From Konark's Sun Temple to Chilika's flamingos, it offers architectural marvels and natural wonders in harmony.",
    foods: [
      {
        name: "Dalma",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Lentils cooked with mixed vegetables, the everyday Odia comfort food."
      },
      {
        name: "Pakhala Bhata",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Fermented rice in water, cooling summer dish with accompaniments."
      },
      {
        name: "Chhena Poda",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Caramelized cottage cheese dessert, baked to perfection."
      }
    ],
    culture: [
      {
        name: "Odissi Dance",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Classical dance with graceful tribhangi postures from temple sculptures."
      },
      {
        name: "Pattachitra",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Traditional cloth-based scroll painting depicting mythology."
      },
      {
        name: "Silver Filigree",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Delicate silver wire jewelry and artifacts from Cuttack."
      }
    ]
  },
  "west-bengal": {
    id: "west-bengal",
    description: "West Bengal, the cultural capital of India, gave birth to the Bengal Renaissance. From Kolkata's colonial grandeur to Darjeeling's tea gardens, it celebrates literature, art, and festive fervor.",
    foods: [
      {
        name: "Rasgulla",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Spongy cottage cheese balls in sugar syrup, Bengal's gift to the world."
      },
      {
        name: "Shorshe Ilish",
        image: "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&q=80",
        description: "Hilsa fish in mustard sauce, the quintessential Bengali delicacy."
      },
      {
        name: "Mishti Doi",
        image: "https://images.unsplash.com/photo-1605196560547-b79f21c00b78?w=800&q=80",
        description: "Sweetened yogurt set in clay pots, creamy and caramelized."
      }
    ],
    culture: [
      {
        name: "Durga Puja Pandals",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Artistic temporary structures housing goddess idols during festival."
      },
      {
        name: "Kantha Embroidery",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Running stitch quilting technique creating beautiful patterns."
      },
      {
        name: "Terracotta Art",
        image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800&q=80",
        description: "Clay sculptures and temple decorations from Bishnupur."
      }
    ]
  },
  "bihar": {
    id: "bihar",
    description: "Bihar, cradle of Buddhism, witnessed Buddha's enlightenment at Bodh Gaya. Ancient seat of learning at Nalanda, it shaped India's philosophical traditions and continues to celebrate rich folk heritage.",
    foods: [
      {
        name: "Litti Chokha",
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=800&q=80",
        description: "Baked wheat balls stuffed with sattu, served with mashed vegetables."
      },
      {
        name: "Thekua",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Fried sweet cookies made during Chhath Puja festival."
      },
      {
        name: "Sattu Paratha",
        image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&q=80",
        description: "Flatbread stuffed with roasted gram flour, protein-rich meal."
      }
    ],
    culture: [
      {
        name: "Madhubani Painting",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Geometric folk art using natural dyes, UNESCO recognized."
      },
      {
        name: "Sikki Grass Craft",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Golden grass weaving for decorative items and toys."
      },
      {
        name: "Chhath Puja",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Ancient sun worship festival unique to Bihar."
      }
    ]
  },
  "jharkhand": {
    id: "jharkhand",
    description: "Jharkhand, land of forests, is rich in minerals and tribal cultures. From Betla's wildlife to ancient temples, it preserves indigenous traditions amidst natural beauty and waterfalls.",
    foods: [
      {
        name: "Dhuska",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
        description: "Deep-fried rice and lentil patties, crispy breakfast favorite."
      },
      {
        name: "Thekua",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Sweet fried cookies offered during Chhath festival."
      },
      {
        name: "Rugra",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Wild mushroom curry, a tribal delicacy from the forests."
      }
    ],
    culture: [
      {
        name: "Chhau Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Martial dance form with elaborate masks, UNESCO heritage."
      },
      {
        name: "Sohrai Painting",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Tribal wall art depicting nature and harvest themes."
      },
      {
        name: "Dokra Metalwork",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Lost-wax casting technique for tribal metal sculptures."
      }
    ]
  },
  "madhya-pradesh": {
    id: "madhya-pradesh",
    description: "Madhya Pradesh, the heart of India, holds UNESCO heritage sites from Khajuraho to Sanchi. Wildlife sanctuaries, tribal culture, and ancient architecture make it a diverse cultural landscape.",
    foods: [
      {
        name: "Poha Jalebi",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
        description: "Flattened rice with crispy sweet spirals, Indore's breakfast combination."
      },
      {
        name: "Bhutte ka Kees",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Grated corn cooked with milk and spices, monsoon specialty."
      },
      {
        name: "Dal Bafla",
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=800&q=80",
        description: "Boiled and baked wheat balls with lentils, MP's comfort food."
      }
    ],
    culture: [
      {
        name: "Gond Art",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Tribal art using dots and lines to depict nature and folklore."
      },
      {
        name: "Chanderi Weaving",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Sheer fabric weaving with gold borders, royal textile heritage."
      },
      {
        name: "Bagh Print",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Hand block printing using natural dyes, GI-tagged craft."
      }
    ]
  },
  "chhattisgarh": {
    id: "chhattisgarh",
    description: "Chhattisgarh, full of surprises, holds India's largest tribal population. Ancient temples, dramatic waterfalls, and untouched forests reveal a region rich in natural and cultural treasures.",
    foods: [
      {
        name: "Chila",
        image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=800&q=80",
        description: "Rice flour pancakes, simple and nutritious tribal breakfast."
      },
      {
        name: "Faraa",
        image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&q=80",
        description: "Steamed rice dumplings with coconut filling, festive treat."
      },
      {
        name: "Dubki Kadhi",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Spiced yogurt curry with gram flour dumplings."
      }
    ],
    culture: [
      {
        name: "Bell Metal Craft",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Traditional metalwork creating utensils and sculptures."
      },
      {
        name: "Bastar Dhokra",
        image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800&q=80",
        description: "Lost-wax metal casting for tribal figurines and art."
      },
      {
        name: "Panthi Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Devotional folk dance of the Satnami community."
      }
    ]
  },
  "sikkim": {
    id: "sikkim",
    description: "Sikkim, small but beautiful, offers Himalayan splendor with Buddhist monasteries. Organic farming pioneer with stunning views of Kanchenjunga, it blends Nepali, Bhutia, and Lepcha cultures.",
    foods: [
      {
        name: "Momos",
        image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=800&q=80",
        description: "Steamed dumplings with various fillings, ubiquitous Himalayan snack."
      },
      {
        name: "Thukpa",
        image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&q=80",
        description: "Hearty noodle soup perfect for cold mountain weather."
      },
      {
        name: "Gundruk",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Fermented leafy greens, traditional Sikkimese side dish."
      }
    ],
    culture: [
      {
        name: "Thangka Painting",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Buddhist scroll paintings on cotton or silk."
      },
      {
        name: "Carpet Weaving",
        image: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800&q=80",
        description: "Tibetan-style carpets with Buddhist motifs and symbols."
      },
      {
        name: "Masked Dances",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Colorful monastery dances during Buddhist festivals."
      }
    ]
  },
  "meghalaya": {
    id: "meghalaya",
    description: "Meghalaya, abode of clouds, is home to living root bridges and the wettest place on Earth. Khasi, Jaintia, and Garo tribes maintain matrilineal traditions in this misty paradise.",
    foods: [
      {
        name: "Jadoh",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Rice cooked with pork and spices, Khasi signature dish."
      },
      {
        name: "Dohneiiong",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Pork with black sesame, rich and flavorful preparation."
      },
      {
        name: "Tungrymbai",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Fermented soybean curry, earthy and nutritious."
      }
    ],
    culture: [
      {
        name: "Cane & Bamboo Craft",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Traditional basketry and household items from local materials."
      },
      {
        name: "Khasi Dress",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Jainsem and dhara traditional attire of Khasi women."
      },
      {
        name: "Nongkrem Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Annual harvest dance of the Khasi tribe."
      }
    ]
  },
  "arunachal-pradesh": {
    id: "arunachal-pradesh",
    description: "Arunachal Pradesh, land of the rising sun, is India's northeastern frontier. Home to 26 major tribes, Tawang Monastery, and pristine landscapes, it offers authentic indigenous experiences.",
    foods: [
      {
        name: "Thukpa",
        image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&q=80",
        description: "Noodle soup with vegetables or meat, warming mountain fare."
      },
      {
        name: "Pika Pila",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Bamboo shoot pickle, tangy and fermented delicacy."
      },
      {
        name: "Apong",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Traditional rice beer, integral to tribal celebrations."
      }
    ],
    culture: [
      {
        name: "Monpa Masks",
        image: "https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?w=800&q=80",
        description: "Ceremonial masks used in Buddhist monastery dances."
      },
      {
        name: "Carpet Weaving",
        image: "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800&q=80",
        description: "Colorful traditional carpets woven by Monpa artisans."
      },
      {
        name: "Tribal Jewelry",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Bead necklaces and silver ornaments of various tribes."
      }
    ]
  },
  "nagaland": {
    id: "nagaland",
    description: "Nagaland, land of festivals, celebrates the famous Hornbill Festival showcasing 16 tribes. Former headhunters now welcome visitors to experience their unique customs, crafts, and warrior heritage.",
    foods: [
      {
        name: "Smoked Pork",
        image: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=800&q=80",
        description: "Signature Naga preparation, pork smoked over wood fire."
      },
      {
        name: "Axone",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Fermented soybean paste used in various dishes."
      },
      {
        name: "Bamboo Shoot Curry",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Tender shoots cooked with meat or vegetables."
      }
    ],
    culture: [
      {
        name: "Naga Shawls",
        image: "https://images.unsplash.com/photo-1601244005535-a48d21d951ac?w=800&q=80",
        description: "Distinctive woven shawls indicating tribe and status."
      },
      {
        name: "Wood Carving",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Traditional carvings depicting tribal motifs and legends."
      },
      {
        name: "War Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Traditional warrior dances performed during festivals."
      }
    ]
  },
  "manipur": {
    id: "manipur",
    description: "Manipur, jewel of India, is home to the floating Loktak Lake and classical Manipuri dance. The polo-playing state blends Hindu and tribal traditions in a picturesque valley setting.",
    foods: [
      {
        name: "Eromba",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Boiled vegetables mashed with fermented fish, tangy and spicy."
      },
      {
        name: "Chamthong",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Light vegetable stew, everyday Manipuri comfort food."
      },
      {
        name: "Singju",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Fresh vegetable salad with fermented fish paste."
      }
    ],
    culture: [
      {
        name: "Manipuri Dance",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Classical Ras Lila dance, graceful and devotional."
      },
      {
        name: "Kauna Craft",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Reed mat weaving for household and decorative items."
      },
      {
        name: "Pottery",
        image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800&q=80",
        description: "Traditional black pottery made without potter's wheel."
      }
    ]
  },
  "assam": {
    id: "assam",
    description: "Assam, gateway to Northeast India, is synonymous with world-famous tea gardens. One-horned rhinos, Kamakhya Temple, and Bihu festival define this land of red rivers and green hills.",
    foods: [
      {
        name: "Khar",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Alkaline dish made with banana peels, unique to Assam."
      },
      {
        name: "Masor Tenga",
        image: "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&q=80",
        description: "Tangy fish curry with tomatoes or elephant apple."
      },
      {
        name: "Pitha",
        image: "https://images.unsplash.com/photo-1589119908995-c6837fa14848?w=800&q=80",
        description: "Rice cakes with coconut and jaggery filling, festive sweet."
      }
    ],
    culture: [
      {
        name: "Muga Silk",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80",
        description: "Golden silk exclusive to Assam, naturally lustrous."
      },
      {
        name: "Bihu Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Joyful spring harvest dance of the Assamese people."
      },
      {
        name: "Cane & Bamboo",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Traditional basketry and furniture making."
      }
    ]
  },
  "mizoram": {
    id: "mizoram",
    description: "Mizoram, land of blue mountains, features rolling hills and the unique Cheraw bamboo dance. The Mizo people maintain strong community bonds and Christian heritage with warm hospitality.",
    foods: [
      {
        name: "Bai",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Boiled vegetables with pork or chicken, everyday staple."
      },
      {
        name: "Sawhchiar",
        image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&q=80",
        description: "Rice porridge cooked with meat, comforting and filling."
      },
      {
        name: "Zu",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=800&q=80",
        description: "Traditional rice wine, part of social gatherings."
      }
    ],
    culture: [
      {
        name: "Cheraw Dance",
        image: "https://images.unsplash.com/photo-1533669955142-6a73332af4db?w=800&q=80",
        description: "Bamboo dance requiring precise rhythmic coordination."
      },
      {
        name: "Puan Weaving",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Traditional wraparound skirts with colorful patterns."
      },
      {
        name: "Cane Baskets",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Functional and decorative items from forest materials."
      }
    ]
  },
  "tripura": {
    id: "tripura",
    description: "Tripura, land of fourteen gods, blends Bengali and tribal influences. Ancient temples, rock carvings at Unakoti, and palace heritage create a unique cultural tapestry in the Northeast.",
    foods: [
      {
        name: "Mui Borok",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Traditional mixed platter with rice, fish, and vegetables."
      },
      {
        name: "Chakhwi",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
        description: "Bamboo shoot preparation, earthy tribal flavor."
      },
      {
        name: "Mosdeng Serma",
        image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80",
        description: "Spicy chutney with tomatoes and chilies."
      }
    ],
    culture: [
      {
        name: "Risa Weaving",
        image: "https://images.unsplash.com/photo-1594040226829-7f251ab46d80?w=800&q=80",
        description: "Traditional upper garment of Tripuri women."
      },
      {
        name: "Bamboo Craft",
        image: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=800&q=80",
        description: "Intricate items from bamboo and cane."
      },
      {
        name: "Hojagiri Dance",
        image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&q=80",
        description: "Balancing dance on earthen pots by Reang tribe."
      }
    ]
  }
}
