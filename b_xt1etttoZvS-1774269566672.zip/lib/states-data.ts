export interface State {
  id: string
  name: string
  image: string
  tagline: string
  highlight: string
  region: "north" | "south" | "east" | "west" | "northeast" | "central"
}

export const states: State[] = [
  // North India
  {
    id: "punjab",
    name: "Punjab",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.48.42%20PM-5HfwQOXiQr9UtZGpDNT7ObLqaVK0by.jpeg",
    tagline: "The Land of Five Rivers",
    highlight: "Golden Temple, Amritsar",
    region: "north"
  },
  {
    id: "uttar-pradesh",
    name: "Uttar Pradesh",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.48.41%20PM-QQrmmqexTOTliS0i8jao3ypvuYITQB.jpeg",
    tagline: "The Spiritual Heart of India",
    highlight: "Varanasi Ghats",
    region: "north"
  },
  {
    id: "uttarakhand",
    name: "Uttarakhand",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%207.00.59%20PM-DZRvODYkqyNW7KKjn6yZreBkDdGAAf.jpeg",
    tagline: "Dev Bhoomi - Land of Gods",
    highlight: "Tungnath Temple",
    region: "north"
  },
  {
    id: "himachal-pradesh",
    name: "Himachal Pradesh",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%207.01.17%20PM-ELNYnCWWcYpHXiRqMdcpJRdAIHd6fM.jpeg",
    tagline: "The Abode of Snow",
    highlight: "Parvati Valley",
    region: "north"
  },
  {
    id: "haryana",
    name: "Haryana",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.22.41%20PM-gQDbGMNFXJYBpvuuxQZL9Ol2gkp6pX.jpeg",
    tagline: "Gateway to North India",
    highlight: "Sheikh Chilli's Tomb",
    region: "north"
  },

  // West India
  {
    id: "rajasthan",
    name: "Rajasthan",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.48.40%20PM-OoC8Y4CPgSWsRPvKBTiTIqDvCJg21k.jpeg",
    tagline: "Land of Kings and Forts",
    highlight: "Hawa Mahal, Jaipur",
    region: "west"
  },
  {
    id: "gujarat",
    name: "Gujarat",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.24.14%20PM-60JcylguAvmLn6FhOWGsaHHc8fY1MF.jpeg",
    tagline: "The Land of Legends",
    highlight: "Palitana Temples",
    region: "west"
  },
  {
    id: "maharashtra",
    name: "Maharashtra",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.25.33%20PM-3ieOzfHymIMMKeEHZ3ZfjYtULKdWUC.jpeg",
    tagline: "Gateway of India",
    highlight: "New Palace, Kolhapur",
    region: "west"
  },
  {
    id: "goa",
    name: "Goa",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%202.47.14%20PM-CXVZAKAaqMnC5picYHzRkjN4WvzM6Z.jpeg",
    tagline: "Pearl of the Orient",
    highlight: "Cabo de Rama Beach",
    region: "west"
  },

  // South India
  {
    id: "andhra-pradesh",
    name: "Andhra Pradesh",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%202.09.30%20PM-js6iOgSgO2kGJVLxLdfralfam7IlOK.jpeg",
    tagline: "Essence of Incredible India",
    highlight: "Kumbhalgarh Fort Style Temple",
    region: "south"
  },
  {
    id: "telangana",
    name: "Telangana",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%202.09.08%20PM-9BrgpLAV6buKCoKW0E587xfRf7MWpD.jpeg",
    tagline: "Treasures of the Deccan",
    highlight: "Kuntala Waterfalls",
    region: "south"
  },
  {
    id: "kerala",
    name: "Kerala",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.48.41%20PM%20%282%29-UvctSKkBIqlfKOML0yKLFrve86YjuS.jpeg",
    tagline: "God's Own Country",
    highlight: "Snake Boat Race",
    region: "south"
  },
  {
    id: "tamil-nadu",
    name: "Tamil Nadu",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.48.42%20PM%20%281%29-sTl4W2MwgrMemNhxUUcMbi9yoA73Ts.jpeg",
    tagline: "Land of Temples",
    highlight: "Dravidian Architecture",
    region: "south"
  },
  {
    id: "karnataka",
    name: "Karnataka",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%207.04.49%20PM-DOeGd4Ag3dPnYQLlOSjcZM9KrBvRT0.jpeg",
    tagline: "One State, Many Worlds",
    highlight: "Namdroling Monastery",
    region: "south"
  },

  // East India
  {
    id: "odisha",
    name: "Odisha",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.48.43%20PM-IIM09xw0Q0TMP4eBO11K05ZnAREX2m.jpeg",
    tagline: "Soul of India",
    highlight: "Rath Yatra, Puri",
    region: "east"
  },
  {
    id: "west-bengal",
    name: "West Bengal",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%207.02.16%20PM-qCAI0VxApVs7nIbPC1S9CK7kcenWyc.jpeg",
    tagline: "Sweetness of Culture",
    highlight: "Durga Puja",
    region: "east"
  },
  {
    id: "bihar",
    name: "Bihar",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.22.33%20PM-4HbRuigfSjQjMewTbN6vLz9gwlWFdt.jpeg",
    tagline: "Cradle of Buddhism",
    highlight: "Mahabodhi Temple, Bodh Gaya",
    region: "east"
  },
  {
    id: "jharkhand",
    name: "Jharkhand",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.21.23%20PM-w15Lo4H5lmXoyCqyuJ8bOGgxKRhz7v.jpeg",
    tagline: "Land of Forests",
    highlight: "Baidyanath Temple",
    region: "east"
  },

  // Central India
  {
    id: "madhya-pradesh",
    name: "Madhya Pradesh",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.33.08%20PM-4xp32qnvFC7knEns1ecAy5RqC232r2.jpeg",
    tagline: "Heart of Incredible India",
    highlight: "Khajuraho Temples",
    region: "central"
  },
  {
    id: "chhattisgarh",
    name: "Chhattisgarh",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%202.47.15%20PM-Mk1fBFehLbTpR44HjSqI8ap6DvDM7o.jpeg",
    tagline: "Full of Surprises",
    highlight: "Bhoramdeo Temple",
    region: "central"
  },

  // Northeast India
  {
    id: "sikkim",
    name: "Sikkim",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.49.53%20PM-aVJkRynRaZXCAoWm3ETsqE1ikDEpFv.jpeg",
    tagline: "Small but Beautiful",
    highlight: "Tsomgo Lake",
    region: "northeast"
  },
  {
    id: "meghalaya",
    name: "Meghalaya",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.49.52%20PM-THQi1uKmH2g9PVNtHsLYW4oofI1M2h.jpeg",
    tagline: "Abode of Clouds",
    highlight: "Khasi Traditional Dance",
    region: "northeast"
  },
  {
    id: "arunachal-pradesh",
    name: "Arunachal Pradesh",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%206.48.41%20PM%20%281%29-WvxUub4zDn0MgBD18BThOaR6voYtnp.jpeg",
    tagline: "Land of Rising Sun",
    highlight: "Tawang Festival",
    region: "northeast"
  },
  {
    id: "nagaland",
    name: "Nagaland",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%202.40.30%20PM-9yjGtyScFtqWmzw12APgKDmezX0Wr1.jpeg",
    tagline: "Land of Festivals",
    highlight: "Dzukou Valley",
    region: "northeast"
  },
  {
    id: "manipur",
    name: "Manipur",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.22.54%20PM-Uj4G2YW5E94dcxLBqzZsONBhI98oz9.jpeg",
    tagline: "Jewel of India",
    highlight: "Govindaji Temple",
    region: "northeast"
  },
  {
    id: "assam",
    name: "Assam",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%201.22.14%20PM-qLC7k6Yh9vl6HxZFQzEbAakLAe0Jfz.jpeg",
    tagline: "Awesome Assam",
    highlight: "Tea Gardens",
    region: "northeast"
  },
  {
    id: "mizoram",
    name: "Mizoram",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-22%20at%202.09.57%20PM-g0SwJC0lFqzwI7ncuayuNeZ7z6385d.jpeg",
    tagline: "Land of Blue Mountains",
    highlight: "Reiek Tlang",
    region: "northeast"
  },
  {
    id: "tripura",
    name: "Tripura",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-21%20at%207.01.33%20PM-ALGCd1NlwUUxrHuN8KfllFEqC59oMg.jpeg",
    tagline: "Land of Fourteen Gods",
    highlight: "Ujjayanta Palace",
    region: "northeast"
  }
]
